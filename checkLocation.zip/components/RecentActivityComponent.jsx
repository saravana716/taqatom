import React from 'react'

const RecentActivityComponent = () => {
  return (
    <div>RecentActivityComponent</div>
  )
}

export default RecentActivityComponent