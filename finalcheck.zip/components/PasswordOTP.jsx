import React from 'react'

const PasswordOTP = () => {
  return (
    <View>
        
    </View>
  )
}

export default PasswordOTP