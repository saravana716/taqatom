export const PUNCH_STATE_OPTIONS = [
    {
      id: 0,
      label: "Check In",
    },
    {
      id: 1,
      label: "Check Out",
    },
    {
      id: 2,
      label: "Break Out",
    },
    {
      id: 3,
      label: "Break In",
    },
    {
      id: 4,
      label: "Overtime In",
    },
    {
      id: 5,
      label: "Overtime Out",
    },
  ];