export const FEATURE_CODES = {
    PERFORMANCE: "performanceManagement",
    PAYROLL: "payroll",
    CONTRACT: "contractManagement",
    ASSET: "assetManagement",
    DOCUMENT: "documentManagement",
  };
  export const PREMIUM_FEATURES = [
    "performanceManagement",
    "payroll",
    "contractManagement",
    "assetManagement",
    "documentManagement",
  ];
  