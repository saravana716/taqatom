export const ROLE = {
  EMPLOYEE: "user",
};
