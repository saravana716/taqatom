export const LANGUAGE_TRANSLATIONS = [
  {
    id: "ar",
    label: "Arabic",
  },
  { id: "en", label: "English" },
];
export const LANG_CODES = {
  ARABIC: "ar",
  ENGLISH: "en",
};
