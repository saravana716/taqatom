import ObjectStorage from '../Modules/ObjectStorage/index';

export default ObjectStorage;
